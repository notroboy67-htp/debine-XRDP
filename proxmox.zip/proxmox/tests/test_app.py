import io, tempfile, os, unittest
from app import create_app, db
from app.models import User, Plan, Payment, VPS

class AppTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.app = create_app({"TESTING": True, "WTF_CSRF_ENABLED": False,
            "SQLALCHEMY_DATABASE_URI": "sqlite:///" + os.path.join(self.tmp.name, "test.db"),
            "RECEIPT_DIR": self.tmp.name, "SECRET_KEY": "test-secret"})
        self.client = self.app.test_client()
        with self.app.app_context():
            db.drop_all(); db.create_all()
            db.session.add(User(email="admin@test.local", password_hash=User.hash_password("long-test-password"), role="admin"))
            db.session.add(User(email="user@test.local", password_hash=User.hash_password("long-test-password"), role="customer"))
            db.session.add(Plan(name="Starter", cpu=1, ram_mb=1024, disk_gb=20, price_paise=10000))
            db.session.commit()
    def tearDown(self):
        with self.app.app_context(): db.session.remove(); db.drop_all()
        self.tmp.cleanup()
    def login(self, email):
        return self.client.post("/login", data={"email":email,"password":"long-test-password"}, follow_redirects=True)
    def test_customer_login(self):
        r=self.login("user@test.local"); self.assertEqual(r.status_code,200); self.assertIn(b"Customer portal",r.data)
    def test_admin_login(self):
        r=self.login("admin@test.local"); self.assertEqual(r.status_code,200); self.assertIn(b"Admin command center",r.data)
    def test_receipt_creates_pending_payment_only(self):
        self.login("user@test.local")
        r=self.client.post("/customer/purchase/1", data={"receipt":(io.BytesIO(b"fake image bytes"),"receipt.png")}, content_type="multipart/form-data", follow_redirects=True)
        self.assertEqual(r.status_code,200)
        with self.app.app_context():
            p=Payment.query.one(); self.assertEqual(p.status,"pending"); self.assertEqual(VPS.query.count(),0)
    def test_unknown_route_404(self):
        self.assertEqual(self.client.get("/no-such-route").status_code,404)

if __name__ == "__main__": unittest.main()
