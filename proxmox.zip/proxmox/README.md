# NRB PROXMOX V1

A Flask-based VPS customer portal and admin panel with a Proxmox VE API adapter.

## Quick start (Linux / Ubuntu)
1. Install Python 3.11+ and create a virtual environment:
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   ```
2. Configure environment:
   ```bash
   cp .env.example .env
   ```
   Export the variables in `.env` (or use your process manager's environment-file support). Set a unique `SECRET_KEY`, bootstrap admin credentials, and Proxmox API token. Never commit `.env`.
3. Run locally:
   ```bash
   set -a; . ./.env; set +a
   flask --app wsgi:app run --host 127.0.0.1 --port 5000
   ```
4. Run tests:
   ```bash
   python -m unittest discover -s tests -v
   ```
5. Production:
   ```bash
   gunicorn --workers 2 --bind 127.0.0.1:8000 wsgi:app
   ```
   Put it behind HTTPS reverse proxy. Set `COOKIE_SECURE=1`. Use PostgreSQL via `DATABASE_URL=postgresql+psycopg://...`.

## Proxmox preparation
- Create a dedicated Proxmox API user and API token with only required VM clone/config/power, node audit and storage permissions.
- Prepare a working QEMU template with cloud-init/network configuration and a known disk bus (default `scsi0`).
- Set `PROXMOX_URL`, token ID/secret, node, template VMID, storage and bridge.
- Keep TLS verification enabled. Install the Proxmox CA certificate on the app host if using a private CA.
- The clone endpoint is asynchronous. This version records `clone_submitted` and the UPID; it does not mark the VPS ready until task polling and guest network discovery are implemented and verified. Disk resize behavior depends on the template disk layout and should be tested on a disposable VM first.

## Payments
This package implements manual receipt submission and admin approval. It is not connected to a payment gateway and does not verify bank/UPI settlement automatically. An admin approval creates a VPS provisioning record and submits a clone request. Do not treat an uploaded receipt as proof of settlement without independently checking the payment.

## Important scope / production checklist
- This is a clean implementation package because no existing project ZIP was attached. It cannot preserve code or payment logic from an unseen project.
- Actual Proxmox cloning/power operations require a reachable configured Proxmox VE server and a correctly permissioned token.
- The included automated tests exercise authentication, receipt submission and database behavior without a live Proxmox server. They do not prove live VM provisioning.
- Replace startup `db.create_all()` with reviewed Flask-Migrate/Alembic revisions before production upgrades. `migrations/README.md` describes initial migration generation.
- Add receipt download authorization, malware scanning, payment gateway/webhook verification, VM task polling, IP discovery, quotas, bandwidth enforcement, node/storage selection UI, suspension/deletion workflows, and production-grade transactional outbox/retry handling before accepting customers.
- Configure backups, monitoring, HTTPS, firewalling, database backups and secret rotation.


## Admin-created Proxmox VPS
The admin dashboard now includes **Create VPS directly on Proxmox**. Select an active customer and plan, enter a VM name, and the panel submits a full clone of `PROXMOX_TEMPLATE_VMID` to `PROXMOX_DEFAULT_NODE`. The clone is asynchronous and is shown as `clone_submitted` until task polling/readiness verification is implemented. Admin and customer dashboards show an **Open VM in Proxmox** link to the VM page. The link opens the Proxmox web UI; it does not bypass Proxmox authentication or provide SSH credentials.

Set `PROXMOX_URL`, `PROXMOX_TOKEN_ID`, `PROXMOX_TOKEN_SECRET`, `PROXMOX_DEFAULT_NODE`, and `PROXMOX_TEMPLATE_VMID` in `.env`. The API token needs the appropriate least-privilege permissions for VM clone and cluster VMID allocation. Ensure the template and storage/network configuration are prepared in Proxmox. Existing SQLite databases may need a migration for the new nullable `payment_id` and `task_upid` fields; back up the database before upgrading.

Default first-run admin credentials: `admin@gmail.com` / `admin`. This is intentionally for local initial setup only. Change it immediately before exposing the panel to any network. Existing admin accounts are not overwritten.
