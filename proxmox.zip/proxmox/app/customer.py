import os, uuid
from flask import Blueprint, render_template, request, redirect, url_for, flash, current_app, abort
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from . import db
from .models import Plan, Payment, VPS
from .services import audit
bp = Blueprint("customer", __name__)
ALLOWED = {"png", "jpg", "jpeg", "pdf"}

@bp.get("/")
@login_required
def dashboard():
    payments = Payment.query.filter_by(user_id=current_user.id).order_by(Payment.created_at.desc()).all()
    vps = VPS.query.filter_by(user_id=current_user.id).all()
    return render_template("customer.html", plans=Plan.query.filter_by(active=True).all(), payments=payments, vps=vps, proxmox_url=os.getenv("PROXMOX_URL", "").rstrip("/"))

@bp.post("/purchase/<int:plan_id>")
@login_required
def purchase(plan_id):
    plan = db.session.get(Plan, plan_id)
    if not plan or not plan.active: abort(404)
    f = request.files.get("receipt")
    if not f or not f.filename or "." not in f.filename:
        flash("Upload a payment receipt."); return redirect(url_for("customer.dashboard"))
    ext = f.filename.rsplit(".", 1)[1].lower()
    if ext not in ALLOWED: abort(400)
    filename = f"{uuid.uuid4().hex}.{ext}"
    path = os.path.join(current_app.config["RECEIPT_DIR"], filename)
    f.save(path)
    payment = Payment(user_id=current_user.id, plan_id=plan.id, amount_paise=plan.price_paise,
                      receipt_path=filename, status="pending")
    db.session.add(payment); db.session.commit()
    audit(current_user.id, "payment.submitted", str(payment.id))
    flash("Receipt submitted. VPS provisioning starts only after admin approval.")
    return redirect(url_for("customer.dashboard"))

@bp.post("/vps/<int:vps_id>/<action>")
@login_required
def power(vps_id, action):
    vm = db.session.get(VPS, vps_id)
    if not vm or vm.user_id != current_user.id: abort(404)
    if not vm.vmid or not vm.node or vm.status not in ("running", "stopped", "clone_submitted"):
        flash("This VPS is not yet ready for power control."); return redirect(url_for("customer.dashboard"))
    try:
        from .proxmox import ProxmoxClient
        ProxmoxClient().power(vm.node, vm.vmid, action)
        audit(current_user.id, f"vps.power.{action}", str(vm.vmid))
        flash(f"{action.title()} request sent to Proxmox.")
    except Exception as exc:
        flash(f"Proxmox request failed: {exc}")
    return redirect(url_for("customer.dashboard"))
