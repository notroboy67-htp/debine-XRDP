from flask import Blueprint, render_template
from .models import Plan
bp = Blueprint("main", __name__)
@bp.get("/")
def index():
    return render_template("index.html", plans=Plan.query.filter_by(active=True).all())
